function f = select_fliter(I, pos , f_a , N)
%select filter set
% I: 3-D img w*h*16
% pos: target position
% N: filter number
% f_a: filter length
%f: 4-D data 6*6*16*N, N denotes the number of filter
% the filter set is obtained from the HSI image at frame 1. 
f=[];
x=pos(1);
y=pos(2);
for i = 1:N,
    shift=randperm(20,1);
f(:,:,:,i) = I((x+shift):(x+shift+f_a-1), (y+shift):(y+shift+f_a-1), :);
end
