clear all;close all;
% addpath('./data/Benchmark')
addpath('C:\Users\kunqian\Documents\data\deer\img')
a=imread('00001.bmp');pos_a=[94 125 50 65];
b=imread('00062.bmp');pos_b=[52 120 50 65];
c=imread('00010.bmp');pos_c=[310 155 50 65];
A=X2Cube2(a);
filter = select_fliter(A, pos_a, 6, 1);
img1=A(pos_a(2):(pos_a(2)+pos_a(4)),pos_a(1):(pos_a(1)+pos_a(3)),:);
B=X2Cube2(b);
img2=B(pos_b(2):(pos_b(2)+pos_b(4)),pos_b(1):(pos_b(1)+pos_b(3)),:);
C=X2Cube2(c);
img3=C(pos_c(2):(pos_c(2)+pos_c(4)),pos_c(1):(pos_c(1)+pos_c(3)),:);

img4=C((pos_c(2)+50):(pos_c(2)+pos_c(4)+50),pos_c(1):(pos_c(1)+pos_c(3)),:);
% load filters;
n=1:14;
h1 = convn(img1,filter(:,:,n),'valid');
figure,imshow(h1(:,:,1),[])
saveas(gcf,['./result/s_',num2str(1),'.png']);
set(gca,'position',[0,0,1,1] );
saveas(gcf,['./result/s_',num2str(1),'.png']);
h2 = convn(img2,filter(:,:,n),'valid');
figure,imshow(h2(:,:,1),[])
set (gca,'position',[0,0,1,1] );
saveas(gcf,['./result/s_',num2str(2),'.png']);
h3 = convn(img3,filter(:,:,n),'valid');
figure,imshow(h3(:,:,1),[])
set (gca,'position',[0,0,1,1] );
saveas(gcf,['./result/s_',num2str(3),'.png']);
h4 = convn(img4,filter(:,:,n),'valid');
figure,imshow(h4(:,:,1),[])
set (gca,'position',[0,0,1,1] );
saveas(gcf,['./result/s_',num2str(4),'.png']);
    
    

