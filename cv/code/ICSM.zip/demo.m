clear
videos={'ball';'basketball'};
for vid =1:numel(videos)
    [positions,ground_truth, fps]=run_tracker(videos{vid});
end