function H = cn(I, filter)
%GET cn FEATURES
% I 3-D
%filter: 4-D data 6*6*16*N, N denotes the number of filter
% the filter set is obtained from the HSI image at frame 1. 
M=size(filter,4);
fea=[];
for i=1:M
    h = convn(I,filter(:,:,:,i),'same');
    H(:,:,i)=h(:,:,1);
end

end



