function [img_files, pos, target_sz, ground_truth, video_path] = load_video_info(video_path)

% [img_files, pos, target_sz, ground_truth, video_path] = load_video_info(video_path)

ground_truth = dlmread([video_path 'HSI/groundtruth_rect.txt']);
%set initial position and size
target_sz = [ground_truth(1,4), ground_truth(1,3)];
pos = [ground_truth(1,2), ground_truth(1,1)] + floor(target_sz/2);
img_path = [ 'HSI/'];
img_files = num2str([1:size(ground_truth,1)]', [img_path '%04i.png']);
% img_files = img_files(4:end);


%list the files
img_files = cellstr(img_files);

end

